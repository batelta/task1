﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_GUIorder
{
    internal class Drinks
    {
        string name;
        int price;
        public Drinks (string name)
        {
            this.name = name;
            this.price = drinkPrice(name);
        }
     
        public int getPrice()
        {
            return price;
        }
        private int drinkPrice(string drinkname)
        {
            switch(drinkname)
            {
            case "None":
                    return 0;
             
             case "Coke":
                    return 14;
          
             case "Sprite":
                    return 12;
             
             case "Fanta":
                    return 12;
                
             case "Water":
                    return 10;
            }
            return 0;
        }
        public string drinktoString()
        {
            string res = "\n\r Your Drink: " + name + " price: " + price+"\n\r";

            return res;

        }

    }
}
