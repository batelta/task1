﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml.Schema;

namespace WindowsFormsApp1_GUIorder
{
    internal class Pizza
    {
        string toppingname;
        string size;
        int price;
        public Pizza()
        {
            toppingname = "Olives";
            size = "Family size";
            price = 33;
        }
        public Pizza (string toppingname,string size)
        {
            this.toppingname = toppingname;
            this.size = size;
                if (size.Equals("Family size"))
                    price = 30;
                else 
                    price = 15;
                if (!(toppingname == "None"))
                    price += 3;   
        }

        public int getPrice()
        {
            return price;   
        }
       public string pizzatoString()
        {
            string res = "\n\r Your Pizza: " + size + " with " + toppingname + " price: " + price+"\n\r";

            return res;

        }
    }
}
