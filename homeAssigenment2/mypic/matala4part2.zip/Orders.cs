﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1_GUIorder
{
    internal class Orders
    {
       
            Pizza[] pizzaArr = new Pizza[0];
            public int pizzaindex = 0;
            Drinks[] drinkArr = new Drinks[0];
            public int indexdrink = 0;
            static int totalprice=0;
        public Orders() 
        {
            pizzaArr = new Pizza[0];
            drinkArr = new Drinks[0];
        }
        public void total()
        {
            totalprice = 0;
        }

        public void addNewPizza(Pizza yourpizza)
        {
            Array.Resize(ref pizzaArr, pizzaArr.Length + 1);
            pizzaArr[pizzaindex++]= yourpizza;
            totalprice+=yourpizza.getPrice();    
        }

        public void addNewDrink(Drinks yourdrink)
        {
            Array.Resize(ref drinkArr, drinkArr.Length + 1);
            drinkArr[indexdrink++] = yourdrink;
            totalprice+=yourdrink.getPrice();   
        }

        public string orderdetails()
        {
            string res=null;
            for (int i = 0; i < pizzaArr.Length; i++)
            {
                if (pizzaArr[i] != null)
                {
                    res += pizzaArr[i].pizzatoString() + " ";
                    res += "\n";
                }
            }
            for (int i = 0; i < drinkArr.Length; i++)
            {
                if (drinkArr[i] != null)
                {
                    res += drinkArr[i].drinktoString();
                    res += "\n";
                }
            }
            if(totalprice!=0)
            res += "\n\r Total :" + totalprice;
            return res;
        }
        public void deleteArr()
        {
            for (int i = pizzaArr.Length; i >0; i--)
            {
                Array.Resize(ref pizzaArr, pizzaArr.Length - 1);
                pizzaindex--;
            }
            for (int i = drinkArr.Length; i >0; i--)
            {
                Array.Resize(ref drinkArr, drinkArr.Length - 1);
                indexdrink--;
            }

        }


    }
}
