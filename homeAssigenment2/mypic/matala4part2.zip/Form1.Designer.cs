﻿using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1_GUIorder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnNeworder = new System.Windows.Forms.Button();
            this.lbltopping = new System.Windows.Forms.Label();
            this.lblpizza = new System.Windows.Forms.Label();
            this.btnOurpizza = new System.Windows.Forms.Button();
            this.lstmenu = new System.Windows.Forms.ListBox();
            this.lbldrinkchoice = new System.Windows.Forms.Label();
            this.btnOrdersummary = new System.Windows.Forms.Button();
            this.btnNewpizza = new System.Windows.Forms.Button();
            this.btnAddpizza = new System.Windows.Forms.Button();
            this.btnAdddrink = new System.Windows.Forms.Button();
            this.txtOrdersummary = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.cmbpizzasize = new System.Windows.Forms.ComboBox();
            this.cmbpizzatopping = new System.Windows.Forms.ComboBox();
            this.cmbdrinkoption = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnPay = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.lblcountdown = new System.Windows.Forms.Label();
            this.lbldone = new System.Windows.Forms.Label();
            this.lblpaymentdeets = new System.Windows.Forms.Label();
            this.txtordernumber = new System.Windows.Forms.TextBox();
            this.btncostumer = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNeworder
            // 
            this.btnNeworder.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNeworder.Location = new System.Drawing.Point(134, 30);
            this.btnNeworder.Name = "btnNeworder";
            this.btnNeworder.Size = new System.Drawing.Size(217, 62);
            this.btnNeworder.TabIndex = 0;
            this.btnNeworder.Text = "Place your Order";
            this.btnNeworder.UseVisualStyleBackColor = true;
            this.btnNeworder.Click += new System.EventHandler(this.btnNeworder_Click);
            // 
            // lbltopping
            // 
            this.lbltopping.AutoSize = true;
            this.lbltopping.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltopping.Location = new System.Drawing.Point(258, 265);
            this.lbltopping.Name = "lbltopping";
            this.lbltopping.Size = new System.Drawing.Size(121, 33);
            this.lbltopping.TabIndex = 5;
            this.lbltopping.Text = "Choose topping:";
            // 
            // lblpizza
            // 
            this.lblpizza.AutoSize = true;
            this.lblpizza.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpizza.Location = new System.Drawing.Point(90, 265);
            this.lblpizza.Name = "lblpizza";
            this.lblpizza.Size = new System.Drawing.Size(90, 33);
            this.lblpizza.TabIndex = 6;
            this.lblpizza.Text = "Pizza size:";
            // 
            // btnOurpizza
            // 
            this.btnOurpizza.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOurpizza.Location = new System.Drawing.Point(113, 109);
            this.btnOurpizza.Name = "btnOurpizza";
            this.btnOurpizza.Padding = new System.Windows.Forms.Padding(1);
            this.btnOurpizza.Size = new System.Drawing.Size(266, 60);
            this.btnOurpizza.TabIndex = 7;
            this.btnOurpizza.Text = "Pick Our signature Pizza";
            this.btnOurpizza.UseVisualStyleBackColor = true;
            this.btnOurpizza.Click += new System.EventHandler(this.btnOurpizza_Click);
            // 
            // lstmenu
            // 
            this.lstmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lstmenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lstmenu.Font = new System.Drawing.Font("Bradley Hand ITC", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstmenu.FormattingEnabled = true;
            this.lstmenu.ItemHeight = 25;
            this.lstmenu.Items.AddRange(new object[] {
            "MENU                                                           Price",
            "",
            "Our pizza :Family sized with Olives               33",
            "Family size pizza                                           30",
            "small pizza                                                     15",
            "Olives                                                               3",
            "Tuna                                                                3",
            "Mushrooms                                                       3",
            "Onions                                                             3",
            "",
            "DRINKS:",
            "Coke                                                               14",
            "Water                                                             10",
            "Sprite                                                             12",
            "Fanta                                                             12"});
            this.lstmenu.Location = new System.Drawing.Point(735, 30);
            this.lstmenu.Name = "lstmenu";
            this.lstmenu.Size = new System.Drawing.Size(477, 379);
            this.lstmenu.TabIndex = 8;
            // 
            // lbldrinkchoice
            // 
            this.lbldrinkchoice.AutoSize = true;
            this.lbldrinkchoice.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldrinkchoice.Location = new System.Drawing.Point(492, 265);
            this.lbldrinkchoice.Name = "lbldrinkchoice";
            this.lbldrinkchoice.Size = new System.Drawing.Size(141, 33);
            this.lbldrinkchoice.TabIndex = 9;
            this.lbldrinkchoice.Text = "Choose your drink:";
            // 
            // btnOrdersummary
            // 
            this.btnOrdersummary.Font = new System.Drawing.Font("Bradley Hand ITC", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrdersummary.Location = new System.Drawing.Point(33, 432);
            this.btnOrdersummary.Name = "btnOrdersummary";
            this.btnOrdersummary.Size = new System.Drawing.Size(189, 84);
            this.btnOrdersummary.TabIndex = 10;
            this.btnOrdersummary.Text = "Order summary";
            this.btnOrdersummary.UseVisualStyleBackColor = true;
            this.btnOrdersummary.Click += new System.EventHandler(this.btnOrdersummary_Click);
            // 
            // btnNewpizza
            // 
            this.btnNewpizza.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewpizza.Location = new System.Drawing.Point(113, 188);
            this.btnNewpizza.Name = "btnNewpizza";
            this.btnNewpizza.Size = new System.Drawing.Size(262, 55);
            this.btnNewpizza.TabIndex = 12;
            this.btnNewpizza.Text = "Make your own Pizza";
            this.btnNewpizza.UseVisualStyleBackColor = true;
            this.btnNewpizza.Click += new System.EventHandler(this.btnNewpizza_Click);
            // 
            // btnAddpizza
            // 
            this.btnAddpizza.Font = new System.Drawing.Font("Bodoni MT Condensed", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddpizza.Location = new System.Drawing.Point(157, 364);
            this.btnAddpizza.Name = "btnAddpizza";
            this.btnAddpizza.Size = new System.Drawing.Size(163, 45);
            this.btnAddpizza.TabIndex = 13;
            this.btnAddpizza.Text = "Add pizza";
            this.btnAddpizza.UseVisualStyleBackColor = true;
            this.btnAddpizza.Click += new System.EventHandler(this.btnAddpizza_Click);
            // 
            // btnAdddrink
            // 
            this.btnAdddrink.Font = new System.Drawing.Font("Bodoni MT Condensed", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdddrink.Location = new System.Drawing.Point(481, 364);
            this.btnAdddrink.Name = "btnAdddrink";
            this.btnAdddrink.Size = new System.Drawing.Size(152, 45);
            this.btnAdddrink.TabIndex = 14;
            this.btnAdddrink.Text = "Add drink";
            this.btnAdddrink.UseVisualStyleBackColor = true;
            this.btnAdddrink.Click += new System.EventHandler(this.btnAdddrink_Click);
            // 
            // txtOrdersummary
            // 
            this.txtOrdersummary.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txtOrdersummary.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrdersummary.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtOrdersummary.Location = new System.Drawing.Point(264, 432);
            this.txtOrdersummary.Multiline = true;
            this.txtOrdersummary.Name = "txtOrdersummary";
            this.txtOrdersummary.Size = new System.Drawing.Size(405, 147);
            this.txtOrdersummary.TabIndex = 15;
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Bradley Hand ITC", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(694, 525);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(142, 54);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "Clear All";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // cmbpizzasize
            // 
            this.cmbpizzasize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbpizzasize.FormattingEnabled = true;
            this.cmbpizzasize.Items.AddRange(new object[] {
            "Family size",
            "Small"});
            this.cmbpizzasize.Location = new System.Drawing.Point(82, 316);
            this.cmbpizzasize.Name = "cmbpizzasize";
            this.cmbpizzasize.Size = new System.Drawing.Size(121, 28);
            this.cmbpizzasize.TabIndex = 20;
            // 
            // cmbpizzatopping
            // 
            this.cmbpizzatopping.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbpizzatopping.FormattingEnabled = true;
            this.cmbpizzatopping.Items.AddRange(new object[] {
            "None",
            "Olives",
            "Tuna",
            "Mushrooms",
            "Onions"});
            this.cmbpizzatopping.Location = new System.Drawing.Point(262, 316);
            this.cmbpizzatopping.Name = "cmbpizzatopping";
            this.cmbpizzatopping.Size = new System.Drawing.Size(121, 28);
            this.cmbpizzatopping.TabIndex = 21;
            // 
            // cmbdrinkoption
            // 
            this.cmbdrinkoption.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbdrinkoption.FormattingEnabled = true;
            this.cmbdrinkoption.Items.AddRange(new object[] {
            "None",
            "Coke",
            "Sprite",
            "Water",
            "Fanta"});
            this.cmbdrinkoption.Location = new System.Drawing.Point(498, 316);
            this.cmbdrinkoption.Name = "cmbdrinkoption";
            this.cmbdrinkoption.Size = new System.Drawing.Size(121, 28);
            this.cmbdrinkoption.TabIndex = 22;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-189, -95);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1664, 861);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // btnPay
            // 
            this.btnPay.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPay.Location = new System.Drawing.Point(1036, 481);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(117, 75);
            this.btnPay.TabIndex = 24;
            this.btnPay.Text = "Done";
            this.btnPay.UseVisualStyleBackColor = true;
            this.btnPay.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // lblcountdown
            // 
            this.lblcountdown.AutoSize = true;
            this.lblcountdown.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblcountdown.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcountdown.ForeColor = System.Drawing.Color.White;
            this.lblcountdown.Location = new System.Drawing.Point(41, 547);
            this.lblcountdown.Name = "lblcountdown";
            this.lblcountdown.Size = new System.Drawing.Size(74, 32);
            this.lblcountdown.TabIndex = 25;
            this.lblcountdown.Text = "Time:";
            // 
            // lbldone
            // 
            this.lbldone.AutoSize = true;
            this.lbldone.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldone.Location = new System.Drawing.Point(405, 188);
            this.lbldone.Name = "lbldone";
            this.lbldone.Size = new System.Drawing.Size(394, 47);
            this.lbldone.TabIndex = 26;
            this.lbldone.Text = "Your order will be ready in 30 minutes!";
            // 
            // lblpaymentdeets
            // 
            this.lblpaymentdeets.AutoSize = true;
            this.lblpaymentdeets.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpaymentdeets.Location = new System.Drawing.Point(466, 266);
            this.lblpaymentdeets.Name = "lblpaymentdeets";
            this.lblpaymentdeets.Size = new System.Drawing.Size(263, 47);
            this.lblpaymentdeets.TabIndex = 27;
            this.lblpaymentdeets.Text = "Payment at the counter ";
            // 
            // txtordernumber
            // 
            this.txtordernumber.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtordernumber.Location = new System.Drawing.Point(474, 109);
            this.txtordernumber.Name = "txtordernumber";
            this.txtordernumber.Size = new System.Drawing.Size(240, 53);
            this.txtordernumber.TabIndex = 28;
            // 
            // btncostumer
            // 
            this.btncostumer.Font = new System.Drawing.Font("Bodoni MT Poster Compressed", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncostumer.Location = new System.Drawing.Point(546, 512);
            this.btncostumer.Name = "btncostumer";
            this.btncostumer.Size = new System.Drawing.Size(142, 54);
            this.btncostumer.TabIndex = 29;
            this.btncostumer.Text = "OK";
            this.btncostumer.UseVisualStyleBackColor = true;
            this.btncostumer.Click += new System.EventHandler(this.btncostumer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1263, 639);
            this.Controls.Add(this.btncostumer);
            this.Controls.Add(this.txtordernumber);
            this.Controls.Add(this.lblpaymentdeets);
            this.Controls.Add(this.lbldone);
            this.Controls.Add(this.lblcountdown);
            this.Controls.Add(this.btnPay);
            this.Controls.Add(this.cmbdrinkoption);
            this.Controls.Add(this.cmbpizzatopping);
            this.Controls.Add(this.cmbpizzasize);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtOrdersummary);
            this.Controls.Add(this.btnAdddrink);
            this.Controls.Add(this.btnAddpizza);
            this.Controls.Add(this.btnNewpizza);
            this.Controls.Add(this.btnOrdersummary);
            this.Controls.Add(this.lbldrinkchoice);
            this.Controls.Add(this.lstmenu);
            this.Controls.Add(this.btnOurpizza);
            this.Controls.Add(this.lblpizza);
            this.Controls.Add(this.lbltopping);
            this.Controls.Add(this.btnNeworder);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNeworder;
        private System.Windows.Forms.Label lbltopping;
        private System.Windows.Forms.Label lblpizza;
        private System.Windows.Forms.Button btnOurpizza;
        private System.Windows.Forms.ListBox lstmenu;
        private System.Windows.Forms.Label lbldrinkchoice;
        private System.Windows.Forms.Button btnOrdersummary;
        private System.Windows.Forms.Button btnNewpizza;
        private System.Windows.Forms.Button btnAddpizza;
        private System.Windows.Forms.Button btnAdddrink;
        private System.Windows.Forms.TextBox txtOrdersummary;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.ComboBox cmbpizzasize;
        private System.Windows.Forms.ComboBox cmbpizzatopping;
        private System.Windows.Forms.ComboBox cmbdrinkoption;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnPay;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Label lblcountdown;
        private Label lbldone;
        private Label lblpaymentdeets;
        private TextBox txtordernumber;
        private Button btncostumer;
    }
}

