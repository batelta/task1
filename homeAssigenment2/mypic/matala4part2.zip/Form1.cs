﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Authentication.ExtendedProtection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_GUIorder
{
    public partial class Form1 : Form
    {

        private int remainingTime = 300;
        Orders yourOrder = new Orders();
        static int ordernum = 1;
        public Form1()
        {
            InitializeComponent();
            timer.Interval = 1000; 
            timer.Tick += timer_Tick; 
            timer.Start();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            clearform();

        }
        private void clearform()
        {
            btnNewpizza.Visible = false;
            btnOurpizza.Visible = false;
            cmbpizzasize.Visible = false;
            cmbpizzatopping.Visible = false;
            cmbdrinkoption.Visible = false;
            btnAdddrink.Visible = false;
            btnAddpizza.Visible = false;
            lbldrinkchoice.Visible = false;
            lblpizza.Visible = false;
            lbltopping.Visible = false;
            btnPay.Visible = false;
            btnClear.Visible = false;
            txtOrdersummary.Visible = false;
            btnOrdersummary.Visible = false;
            lbldone.Visible = false;
            lblpaymentdeets.Visible = false;
            txtordernumber.Visible = false; 
            btncostumer.Visible = false;
        }
        private void buttoncontrol()
        {
            btnPay.Visible = true;
            btnOrdersummary.Visible = true;
            txtOrdersummary.Visible = true;
            btnClear.Visible = true;
        }
        private void btnOurpizza_Click(object sender, EventArgs e)
        {
            Pizza ourpizza = new Pizza();
            yourOrder.addNewPizza(ourpizza);
            MessageBox.Show("Pizza selected!");
            buttoncontrol();
        }
        private void btnNewpizza_Click(object sender, EventArgs e)
        {
            cmbpizzasize.Visible = true;
            cmbpizzatopping.Visible = true;
            btnAddpizza.Visible = true;
            lblpizza.Visible = true;
            lbltopping.Visible = true;
        }
        private void btnAddpizza_Click(object sender, EventArgs e)
        {
            if (cmbpizzasize.Text == "" || cmbpizzatopping.Text == "")
            {
                MessageBox.Show("You must choose the size and the topping!");
                cmbpizzasize.SelectedIndex = -1;
                cmbpizzatopping.SelectedIndex = -1;
            }
            else
            {
                Pizza newpizza = new Pizza(cmbpizzatopping.Text, cmbpizzasize.Text);
                yourOrder.addNewPizza(newpizza);
                MessageBox.Show("pizza selected");
                cmbpizzasize.SelectedIndex = -1;
                cmbpizzatopping.SelectedIndex = -1;
                buttoncontrol();
            }
        }
        private void btnAdddrink_Click(object sender, EventArgs e)
        {
            if (cmbdrinkoption.Text == "")
                MessageBox.Show("You must choose a drink first");
            else
            {
                MessageBox.Show("drink selected");
                Drinks newdrink = new Drinks(cmbdrinkoption.Text);
                yourOrder.addNewDrink(newdrink);
                cmbdrinkoption.SelectedIndex = -1;
                buttoncontrol();
            }
        }
        private void btnOrdersummary_Click(object sender, EventArgs e)
        {
            txtOrdersummary.Text = yourOrder.orderdetails();
        }

        private void btnNeworder_Click(object sender, EventArgs e)
        {
            btnNewpizza.Visible = true;
            btnOurpizza.Visible = true;
            lbldrinkchoice.Visible = true;
            btnAdddrink.Visible = true;
            cmbdrinkoption.Visible = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {

            while(yourOrder.indexdrink != 0||yourOrder.pizzaindex != 0)
            {
                yourOrder.deleteArr();
            }
            yourOrder.total();

            MessageBox.Show("Deleting your order");
            txtOrdersummary.Clear();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            if (yourOrder != null)
            {
                this.BackColor = Color.Wheat;
                txtordernumber.Text = "ORDER #" + ordernum++;
                clearform();
                btnNeworder.Visible = false;
                lstmenu.Visible = false;
                lbldone.Visible = true;
                lblpaymentdeets.Visible = true;
                txtordernumber.Visible = true;
                btncostumer.Visible = true; 
                timer.Stop();   
                lblcountdown.Visible = false;
            }
        }
        private void resetForm()
        {
            btnNeworder.Visible = true;
            lblcountdown.Visible = true;  
            lstmenu.Visible=true;
            lbldone.Visible = false;
            lblpaymentdeets.Visible = false;
            txtordernumber.Visible = false;
            btncostumer.Visible = false;    
            RestartTimer();
            yourOrder.total();
            txtOrdersummary.Text = "";
            while (yourOrder.indexdrink != 0 || yourOrder.pizzaindex != 0)
            {
                yourOrder.deleteArr();
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            remainingTime--; 

            if (remainingTime >= 0)
            {
                lblcountdown.Text = TimeSpan.FromSeconds(remainingTime).ToString(@"mm\:ss"); 
                TimeSpan timeSpan = TimeSpan.FromSeconds(remainingTime);
                lblcountdown.Text = timeSpan.ToString(@"mm\:ss");
            }
            else
            {
                timer.Stop(); 
                lblcountdown.Text = "Time's up! deleting your order..";
                RestartTimer();
                txtOrdersummary.Clear();
                yourOrder.deleteArr();
                yourOrder.total();
            }
        }
        private void RestartTimer()
        {
            remainingTime = 300; 
            timer.Start(); 
        }

        private void btncostumer_Click(object sender, EventArgs e)
        {
            resetForm();
        }
    }
}
